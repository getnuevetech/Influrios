# Influrios staging visual audit pack

**Status:** Ready for Ola review  
**Staging:** https://influrios.com  
**Generated / reviewed:** 2026-11-18 (Playwright pack + visual issue review)  
**Agency:** deferred / untested (see [coverage](./coverage.md))  
**Policy:** No real money, no real customer notifications, no UI redesign, Payment Standard v2 paused.

## Browse

| Deliverable | Link |
|-------------|------|
| **HTML atlas (browsable)** | [index.html](./index.html) |
| **Screen atlas (markdown)** | [atlas.md](./atlas.md) |
| **Customer journeys** | [journeys.md](./journeys.md) |
| **Workflow recordings** | [recordings.md](./recordings.md) |
| **Issue register** | [issues.md](./issues.md) |
| **Coverage report** | [coverage.md](./coverage.md) |
| **Route inventory** | [inventory.md](./inventory.md) |
| **Credentials / staging notes** | [../staging-visual-audit-credentials.md](../staging-visual-audit-credentials.md) |

Media root: `/cursor/stores/self/media/visual-audit/` (screenshots + recordings + `manifest.json`).

**Full download (docs + all screenshots + videos):** [influrios-visual-audit-pack.zip](./influrios-visual-audit-pack.zip) (~78MB).

## Roles covered

- Public (guest)
- Influencer (`AUDIT_INFLUENCER_*`)
- Business (`AUDIT_BUSINESS_*`)
- Admin (`AUDIT_ADMIN_*`)
- **Agency — skipped** per preferences

## Method

1. Inventory routes from the Influrios repository.
2. Playwright against https://influrios.com with Cloud Agent `AUDIT_*` secrets.
3. Desktop + mobile captures; opportunistic tabs/dialogs/validation/restricted states.
4. Short workflow recordings without payment confirmation or customer notification sends.

## Counts

- Screenshots: **275**
- Recordings: **4**
- Issue register entries: **7** (2 high, 3 medium, 2 low) — start at [issues.md](./issues.md)
